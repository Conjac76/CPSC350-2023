#include "Mario.h"
#include "World.h"
#include <fstream>
#include <iostream>

class Game {
    public:
        Game();
        ~Game();
        Game(std::string file, std::string outputFile);
    private:
};