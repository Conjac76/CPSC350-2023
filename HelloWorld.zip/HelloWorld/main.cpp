#include "HelloWorld.h"

int main() {
    HelloWorld printer;
    printer.printHelloWorld();
}