Connor Jacobs
2395380
This program has a constructor, destructor and a method. The method displays "Hello World!" to the standard console. 