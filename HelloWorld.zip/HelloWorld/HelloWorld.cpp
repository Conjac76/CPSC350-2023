#include "HelloWorld.h"
#include <iostream>

HelloWorld::HelloWorld() {
}

HelloWorld::~HelloWorld() {
}

void HelloWorld::printHelloWorld() {
    std::cout << "Hello World!" << std::endl;
}




