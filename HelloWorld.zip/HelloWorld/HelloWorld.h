class HelloWorld {
public:
    HelloWorld();
    ~HelloWorld();
    void printHelloWorld();
};
