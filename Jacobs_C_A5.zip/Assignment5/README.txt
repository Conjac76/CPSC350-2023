Connor Jacobs
2395380
Rene German

The faculty ID can be set to -1. This represents a null faculty ID. Thus a student can be created
without setting them equal to a specific faculty member. 

In the menu method there is commented out code to hard code some students and faculty in that way
you don't have to tediously do it through terminal. 